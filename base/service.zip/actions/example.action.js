module.exports = {
    async handler(ctx) {
        return {
            message: "Hello World"
        }
    }
}
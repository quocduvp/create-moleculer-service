const Mongoose = require("mongoose");

const MODEL_COLLECTION = "clinic_doctor";

const { Schema } = Mongoose;
const options = {
    collection: MODEL_COLLECTION,
    timestamps: {
        createdAt: "createTime",
        updatedAt: "updateTime",
    },
    strict: false,
};

const thisSchema = new Schema({
    id: String,
    //   field: Type 
}, options);

module.exports = thisSchema;

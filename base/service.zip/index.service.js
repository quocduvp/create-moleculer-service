const CronMixin = require("../../mixins/cron.mixin");
const QueueMixin = require("../../mixins/queue.mixin");
const MongoMixin = require("../../mixins/mongo.mixin");
const AutoLoadMixin = require("../../mixins/autoload.mixin");

const Schema = require("./model/schema");
const Validator = require("./model/validator");
const crons = require("./crons");

module.exports = {
  name: "serviceName",
  version: 1,

  /**
   * Mixins, load from bottom to top
   */
  mixins: [
    CronMixin,
    QueueMixin,
    MongoMixin(),
    AutoLoadMixin(__dirname),
  ],

  /**
   * Model Name
   */
  modelName: "modelName",

  /**
   * Schema
   */
  schema: Schema,

  /**
   * Soft Remove
   */
  softDelete: true,

  /**
   * Settings
   */
  settings: {
    $dependencyTimeout: 10000,
    entityValidator: Validator,
  },

  /**
   * Dependencies
   */
  dependencies: [
  ],

  /**
   * Autoloads
   */
  autoloads: {
    actions: "**/*.action.js",
    methods: "**/*.method.js",
    events: "**/*.event.js",
    hooks: "**/*.hook.js",
  },

  /**
   * Actions
   */
  actions: {},

  /**
   * Methods
   */
  methods: {},

  /**
   * Events handler
   */
  events: {},

  /**
   * Action Hooks
   */
  hooks: {},

  /**
   * CronJobs
   */
  crons,

  /**
   * Fired after database connection establishing.
   */
  // async afterConnected() {
  // },
};
